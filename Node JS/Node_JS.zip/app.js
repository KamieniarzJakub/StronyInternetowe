const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

const db = mysql.createConnection({
    host: 'localhost',
    user: 'website',
    password: '',
    database: 'gamestore'
});

db.connect();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.use(session({
    secret: 'storesecret',
    resave: false,
    saveUninitialized: true
}));

app.use((req, res, next) => {
    if (!req.session.cart) req.session.cart = [];
    next();
});

app.get('/', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        const cartCount = req.session.cart.length;
        const cartIds = req.session.cart;
        res.render('index', {
            products: results,
            message: req.session.message,
            cartCount,
            cartIds
        });
        delete req.session.message;
    });
});


app.post('/add-to-cart', (req, res) => {
    const productId = parseInt(req.body.productId);
    if (!req.session.cart.includes(productId)) {
        req.session.cart.push(productId);
    }
    res.redirect('/');
});

app.get('/cart', (req, res) => {
    const cart = req.session.cart;
    const message = req.session.message;
    delete req.session.message;

    if (cart.length === 0) {
        return res.render('cart', { items: [], message, cartCount: 0 });
    }

    db.query('SELECT * FROM products WHERE id IN (?)', [cart], (err, results) => {
        if (err) throw err;

        const availableIds = results.map(p => p.id);
        const unavailableIds = cart.filter(id => !availableIds.includes(id));

        if (unavailableIds.length > 0) {
            req.session.cart = cart.filter(id => availableIds.includes(id));

            req.session.message = 'Some items were removed from your cart as they are no longer available.';
            return res.redirect('/cart');
        }

        res.render('cart', {
            items: results,
            message,
            cartCount: req.session.cart.length
        });
    });
});



app.post('/remove-from-cart', (req, res) => {
    const productId = parseInt(req.body.productId);
    req.session.cart = req.session.cart.filter(id => id !== productId);
    res.redirect('/cart');
});

app.post('/cancel', (req, res) => {
    req.session.cart = [];
    req.session.message = 'Purchase cancelled.';
    res.redirect('/');
});

app.post('/checkout', (req, res) => {
    const cart = [...req.session.cart];

    db.query('SELECT id FROM products WHERE id IN (?)', [cart], (err, results) => {
        const availableIds = results.map(p => p.id);
        const unavailable = cart.filter(id => !availableIds.includes(id));

        if (unavailable.length > 0) {
            req.session.cart = req.session.cart.filter(id => !unavailable.includes(id));
            req.session.message = 'Purchase CANCELED - Some items were already sold and have been removed from your cart.';
            return res.redirect('/cart');
        }

        db.query('DELETE FROM products WHERE id IN (?)', [cart], (err2) => {
            if (err2) throw err2;
            req.session.cart = [];
            req.session.message = 'Purchase successful!';
            res.redirect('/');
        });
    });
});

app.listen(port, () => {
    console.log(`Game Store running at http://localhost:${port}`);
});
